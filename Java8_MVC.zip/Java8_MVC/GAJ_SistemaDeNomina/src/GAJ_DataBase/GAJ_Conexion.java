package GAJ_DataBase;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GAJ_Conexion {
    public static Connection conexion = null;
    private static final Driver driverDerby = new org.apache.derby.jdbc.ClientDriver();
    private static String URLDerby = "jdbc:derby://localhost:1527/SistemaDeNomina";
   
    private static String usuario = "alberto";
    private static String consenaDB = "123";

    public static Connection obtenerConexion() throws SQLException {
        DriverManager.registerDriver(driverDerby);
        conexion = DriverManager.getConnection(URLDerby, usuario, consenaDB);
        return conexion;
    }
    
    public String buscarEmpleado(int idEmpleado) throws SQLException {
        String empleadoEncontrado = "";
        PreparedStatement consulta = conexion.prepareStatement("SELECT * FROM ALBERTO.EMPLEADOS WHERE ID_EMPLEADO=" + idEmpleado);

        ResultSet conjuntoResultados = consulta.executeQuery();

        while (conjuntoResultados.next()) {

            empleadoEncontrado += conjuntoResultados.getString("ID_EMPLEADO") + "-";
            empleadoEncontrado += conjuntoResultados.getString("NOMBRE") + "-";
            empleadoEncontrado += conjuntoResultados.getString("APELLIDOS") + "-";
            empleadoEncontrado += conjuntoResultados.getString("TIPO_EMPLEADO") ;          

        }
        return empleadoEncontrado;

    }
    
    public String buscarCliente(int idCliente) throws SQLException {
        String clienteEncontrado = "";
        PreparedStatement consulta = conexion.prepareStatement("SELECT * FROM ALBERTO.CLIENTES WHERE ID_CLIENTE=" + idCliente);

        ResultSet conjuntoResultados = consulta.executeQuery();

        while (conjuntoResultados.next()) {

            clienteEncontrado += conjuntoResultados.getString("ID_CLIENTE") + "-";
            clienteEncontrado += conjuntoResultados.getString("NOMBRE") + "-";
            clienteEncontrado += conjuntoResultados.getString("APELLIDOS") + "-";
            clienteEncontrado += conjuntoResultados.getString("TELEFONO") + "-";
            clienteEncontrado += conjuntoResultados.getString("EMAIL") ;
        }
        return clienteEncontrado;

    }
    
    public String buscarProducto(int idProducto) throws SQLException {
        String productoEncontrado = "";
        PreparedStatement consulta = conexion.prepareStatement("SELECT * FROM ALBERTO.INVENTARIOS WHERE ID_PRODUCTO=" + idProducto);

        ResultSet conjuntoResultados = consulta.executeQuery();

        while (conjuntoResultados.next()) {

            productoEncontrado += conjuntoResultados.getString("ID_PRODUCTO") + "-";
            productoEncontrado += conjuntoResultados.getString("NOMBRE") + "-";
            productoEncontrado += conjuntoResultados.getString("PROVEEDOR") + "-";
            productoEncontrado += conjuntoResultados.getString("TELEFONO") + "-";
            productoEncontrado += conjuntoResultados.getString("EMAIL") ;
        }
        return productoEncontrado;

    }
    
    
}
