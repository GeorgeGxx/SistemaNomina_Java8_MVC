
package GAJ_Controlador;


public class GAJ_EmpleadoAsalariado extends GAJ_Empleado {
    private double salario;

    public GAJ_EmpleadoAsalariado(String nombre, String apellidos, String id, double salario) {
        super(nombre, apellidos, id);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override //metodo
    public double ingresos() {
        return getSalario();
    }

    @Override //toString
    public String toString() {
        return String.format("Empleado Asalariado: %s \n\tIngresos: %,.2f",super.toString(),ingresos());
    }
    
    
}
