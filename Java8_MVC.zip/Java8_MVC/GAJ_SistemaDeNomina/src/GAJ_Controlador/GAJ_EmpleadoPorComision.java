
package GAJ_Controlador;


public class GAJ_EmpleadoPorComision extends GAJ_Empleado{
    private double porcentajeComision;
    private double ventasBrutas;

    public GAJ_EmpleadoPorComision(String nombre, String apellidos, String id, double porcentajeComision, double ventasBrutas) {
        super(nombre, apellidos, id);
        this.porcentajeComision = porcentajeComision;
        this.ventasBrutas = ventasBrutas;
    }

    public double getPorcentajeComision() {
        return porcentajeComision;
    }

    public void setPorcentajeComision(double porcentajeComision) {
        this.porcentajeComision = porcentajeComision;
    }

    public double getVentasBrutas() {
        return ventasBrutas;
    }

    public void setVentasBrutas(double ventasBrutas) {
        this.ventasBrutas = ventasBrutas;
    }

    @Override
    public double ingresos() {
        return getVentasBrutas()*getPorcentajeComision();
    }
    
    @Override //toString
    public String toString() {
        return String.format("Empleado Por Comision: %s \n\tIngresos: %,.2f",super.toString(),ingresos());
     
    }
    
}
