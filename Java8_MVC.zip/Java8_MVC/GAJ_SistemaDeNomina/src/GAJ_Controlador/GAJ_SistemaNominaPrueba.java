
package GAJ_Controlador;


public class GAJ_SistemaNominaPrueba {
    public static void main(String[] args) {
        GAJ_EmpleadoAsalariado godinez = new GAJ_EmpleadoAsalariado("Pedro","Godinez Gomez","0001",1500); 
        System.out.println(godinez);
        
        GAJ_EmpleadoAsalariado laSiSiSi = new GAJ_EmpleadoAsalariado("Consuelo","Dubal","0002",3000); 
        System.out.println(laSiSiSi);
        
        GAJ_EmpleadoPorHoras cristobal = new GAJ_EmpleadoPorHoras("Cristóbal","Hérnandez","0003", 7.5, 1000);
        System.out.println(cristobal);
        
        GAJ_EmpleadoPorComision peritos = new GAJ_EmpleadoPorComision("Pedro","De Alba","666", .10, 10000);
        System.out.println(peritos);
        
        GAJ_EmpleadoBaseMasComision fulano = new GAJ_EmpleadoBaseMasComision("Fulano","Sanchez Lopez","234",.20,10000,2000);
        System.out.println(fulano);
    }
    
}
