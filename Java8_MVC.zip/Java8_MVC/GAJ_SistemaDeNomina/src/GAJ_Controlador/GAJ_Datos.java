
package GAJ_Controlador;


public class GAJ_Datos {
    public boolean validarUsuario(String usuario,String contrasena){
            if (usuario.equals("alberto") && contrasena.equals("123")) {
                return true;
            } else {
                return false;
            }
    }
}