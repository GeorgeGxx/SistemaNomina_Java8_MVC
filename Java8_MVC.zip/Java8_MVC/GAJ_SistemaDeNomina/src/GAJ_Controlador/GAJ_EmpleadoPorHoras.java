
package GAJ_Controlador;


public class GAJ_EmpleadoPorHoras extends GAJ_Empleado{
    private double horasTrabajadas;
    private double sueldoPorHora;

    public GAJ_EmpleadoPorHoras(String nombre, String apellidos, String id, double horasTrabajadas, double sueldoPorHora) {
        super(nombre, apellidos, id);
        this.horasTrabajadas = horasTrabajadas;
        this.sueldoPorHora = sueldoPorHora;
    }

    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(double horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public double getSueldoPorHora() {
        return sueldoPorHora;
    }

    public void setSueldoPorHora(double sueldoPorHora) {
        this.sueldoPorHora = sueldoPorHora;
    }

    @Override
    public double ingresos() {
        return getHorasTrabajadas()*getSueldoPorHora();
    }

    @Override //toString
    public String toString() {
        return String.format("Empleado Por Horas: %s \n\tIngresos: %,.2f",super.toString(),ingresos());
     
    }

    
    
    
    
}
