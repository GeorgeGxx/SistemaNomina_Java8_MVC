
package GAJ_Controlador;


public abstract class GAJ_Empleado {
   private String nombre;
   private String apellidos;
   private String id;

    public GAJ_Empleado(String nombre, String apellidos, String id) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
   
   public abstract double ingresos();

    @Override
    public String toString() {
        return String.format("%s %s %s", getId(),getNombre(),getApellidos()) ;
    }
   
   
}
