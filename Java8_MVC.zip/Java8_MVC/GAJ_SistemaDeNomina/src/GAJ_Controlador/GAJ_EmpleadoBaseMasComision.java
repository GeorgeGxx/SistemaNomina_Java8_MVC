
package GAJ_Controlador;


public class GAJ_EmpleadoBaseMasComision extends GAJ_EmpleadoPorComision{
    private double salarioBase;

    public GAJ_EmpleadoBaseMasComision(String nombre, String apellidos, String id, double porcentajeComision, double ventasBrutas, double salarioBase) {
        super(nombre, apellidos, id, porcentajeComision, ventasBrutas);
        this.salarioBase = salarioBase;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    @Override
    public double ingresos() {
        return super.ingresos()+getSalarioBase();
    }
    
     @Override //toString
    public String toString() {
        return String.format("Empleado base y %s ",super.toString());
     
    }
        
}
